package org.example.ibis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IbisApplication {
    public static void main(String[] args) {
        SpringApplication.run(IbisApplication.class, args);
    }
}