package org.example.ibis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IbisApplicationTests {

    @Test
    void contextLoads() {
    }

}
